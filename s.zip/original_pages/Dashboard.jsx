import { motion } from 'framer-motion';
import { Shield, AlertTriangle, Activity, TrendingUp } from 'lucide-react';
import StatCard from '../components/StatCard';
import ThreatCard from '../components/ThreatCard';
import { agentStatus, recentThreats, threatStats } from '../data/mockData';
import { fadeIn, staggerContainer } from '../utils/motion';

const Dashboard = () => {
  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={fadeIn} className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Threat Intelligence Dashboard</h1>
        <p className="text-gray-400">Real-time security insights powered by AI</p>
      </motion.div>

      <motion.div variants={fadeIn} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Critical Threats"
          value={threatStats.critical}
          icon={AlertTriangle}
          color="red"
          trend="+12%"
        />
        <StatCard
          title="Active IOCs"
          value={threatStats.activeIOCs}
          icon={Activity}
          color="orange"
          trend="+8%"
        />
        <StatCard
          title="Vulnerabilities"
          value={threatStats.vulnerabilities}
          icon={Shield}
          color="yellow"
          trend="-3%"
        />
        <StatCard
          title="Risk Score"
          value={threatStats.riskScore}
          icon={TrendingUp}
          color="blue"
          trend="+5%"
        />
      </motion.div>

      <motion.div variants={fadeIn} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h2 className="text-2xl font-semibold text-white mb-4">Agent Status</h2>
        <div className="space-y-4">
          {agentStatus.map((agent) => (
            <div key={agent.id} className="flex items-center justify-between p-4 bg-gray-900 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${
                  agent.status === 'Critical' ? 'bg-red-500' :
                  agent.status === 'Warning' ? 'bg-orange-500' :
                  'bg-blue-500'
                } animate-pulse`} />
                <div>
                  <h3 className="text-lg font-medium text-white">{agent.name}</h3>
                  <p className="text-sm text-gray-400">{agent.description}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-white">{agent.confidence}% Confidence</div>
                <div className={`text-xs ${
                  agent.status === 'Critical' ? 'text-red-400' :
                  agent.status === 'Warning' ? 'text-orange-400' :
                  'text-blue-400'
                }`}>{agent.status}</div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div variants={fadeIn}>
        <h2 className="text-2xl font-semibold text-white mb-4">Recent Threats</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {recentThreats.slice(0, 4).map((threat) => (
            <ThreatCard key={threat.id} threat={threat} />
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Dashboard;