import { motion } from 'framer-motion';
import { useState } from 'react';
import { Rss, ExternalLink, Filter } from 'lucide-react';
import { threatFeeds } from '../data/mockData';
import { fadeIn, staggerContainer } from '../utils/motion';
import Button from '../components/Button';

const ThreatFeeds = () => {
  const [filter, setFilter] = useState('all');
  
  const filtered = filter === 'all' 
    ? threatFeeds 
    : threatFeeds.filter(feed => feed.status === filter);

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={fadeIn} className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Threat Intelligence Feeds</h1>
          <p className="text-gray-400">Monitor and analyze external threat sources</p>
        </div>
        <div className="flex items-center space-x-3">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-gray-800 text-white px-4 py-2 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Feeds</option>
            <option value="active">Active</option>
            <option value="warning">Warning</option>
            <option value="error">Error</option>
          </select>
        </div>
      </motion.div>

      <motion.div variants={fadeIn} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filtered.map((feed) => (
          <motion.div
            key={feed.id}
            whileHover={{ scale: 1.02 }}
            className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-gray-600 transition-colors"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Rss className="w-6 h-6 text-blue-400" />
                <div>
                  <h3 className="text-xl font-semibold text-white">{feed.name}</h3>
                  <p className="text-sm text-gray-400">{feed.source}</p>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                feed.status === 'active' ? 'bg-green-500/20 text-green-400' :
                feed.status === 'warning' ? 'bg-orange-500/20 text-orange-400' :
                'bg-red-500/20 text-red-400'
              }`}>
                {feed.status}
              </div>
            </div>
            
            <p className="text-gray-300 mb-4">{feed.description}</p>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-gray-900 rounded-lg p-3">
                <div className="text-sm text-gray-400 mb-1">IOCs Today</div>
                <div className="text-2xl font-bold text-white">{feed.iocsToday}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-3">
                <div className="text-sm text-gray-400 mb-1">Reliability</div>
                <div className="text-2xl font-bold text-white">{feed.reliability}%</div>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Last updated: {feed.lastUpdate}</span>
              <Button variant="ghost" size="sm">
                <ExternalLink className="w-4 h-4 mr-2" />
                View Feed
              </Button>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default ThreatFeeds;