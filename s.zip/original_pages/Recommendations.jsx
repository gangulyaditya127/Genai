import { motion } from 'framer-motion';
import { useState } from 'react';
import { Brain, CheckCircle, Clock, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { aiRecommendations } from '../data/mockData';
import { fadeIn, staggerContainer } from '../utils/motion';
import Button from '../components/Button';

const Recommendations = () => {
  const [expanded, setExpanded] = useState({});

  const toggleExpand = (id) => {
    setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'Critical': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'High': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default: return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
    }
  };

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={fadeIn} className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <Brain className="w-10 h-10 text-blue-400" />
          <h1 className="text-4xl font-bold text-white">AI-Powered Recommendations</h1>
        </div>
        <p className="text-gray-400">Actionable security insights with explainable reasoning</p>
      </motion.div>

      <motion.div variants={fadeIn} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">{aiRecommendations.length}</div>
            <div className="text-sm text-gray-400">Active Recommendations</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-red-400 mb-2">
              {aiRecommendations.filter(r => r.priority === 'Critical').length}
            </div>
            <div className="text-sm text-gray-400">Critical Actions</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">87%</div>
            <div className="text-sm text-gray-400">Avg Confidence</div>
          </div>
        </div>
      </motion.div>

      <motion.div variants={fadeIn} className="space-y-4">
        {aiRecommendations.map((rec) => (
          <motion.div
            key={rec.id}
            whileHover={{ scale: 1.01 }}
            className="bg-gray-800 rounded-lg border border-gray-700 hover:border-gray-600 transition-colors overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-xl font-semibold text-white">{rec.title}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getPriorityColor(rec.priority)}`}>
                      {rec.priority} Priority
                    </span>
                  </div>
                  <p className="text-gray-300">{rec.description}</p>
                </div>
                <div className="text-right ml-6">
                  <div className="text-sm text-gray-400 mb-1">Confidence</div>
                  <div className="text-2xl font-bold text-white">{rec.confidence}%</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="bg-gray-900 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-2">Impact</div>
                  <p className="text-sm text-white">{rec.impact}</p>
                </div>
                <div className="bg-gray-900 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-2">Estimated Effort</div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-blue-400" />
                    <span className="text-sm text-white">{rec.effort}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                <button
                  onClick={() => toggleExpand(rec.id)}
                  className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors"
                >
                  <span className="text-sm font-medium">View Reasoning</span>
                  {expanded[rec.id] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm">
                    Dismiss
                  </Button>
                  <Button variant="primary" size="sm">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Execute
                  </Button>
                </div>
              </div>
            </div>

            {expanded[rec.id] && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="bg-gray-900 p-6 border-t border-gray-700"
              >
                <h4 className="text-lg font-semibold text-white mb-3">AI Reasoning</h4>
                <p className="text-gray-300 mb-4">{rec.reasoning}</p>
                
                <h4 className="text-lg font-semibold text-white mb-3">Recommended Actions</h4>
                <ul className="space-y-2">
                  {rec.actions.map((action, idx) => (
                    <li key={idx} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300">{action}</span>
                    </li>
                  ))}
                </ul>

                {rec.requiresApproval && (
                  <div className="flex items-center space-x-2 mt-4 p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-orange-400" />
                    <span className="text-sm text-orange-400 font-medium">This action requires analyst approval before execution</span>
                  </div>
                )}
              </motion.div>
            )}
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default Recommendations;