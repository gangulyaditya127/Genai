import { motion } from 'framer-motion';
import { useState } from 'react';
import { Search, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { iocCorrelations } from '../data/mockData';
import { fadeIn, staggerContainer } from '../utils/motion';
import Button from '../components/Button';

const IOCCorrelation = () => {
  const [search, setSearch] = useState('');
  
  const filtered = search
    ? iocCorrelations.filter(ioc => 
        ioc.indicator.toLowerCase().includes(search.toLowerCase()) ||
        ioc.type.toLowerCase().includes(search.toLowerCase())
      )
    : iocCorrelations;

  const getRiskColor = (risk) => {
    switch(risk) {
      case 'High': return 'text-red-400 bg-red-500/20';
      case 'Medium': return 'text-orange-400 bg-orange-500/20';
      case 'Low': return 'text-green-400 bg-green-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      <motion.div variants={fadeIn} className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">IOC Correlation Engine</h1>
        <p className="text-gray-400">Match indicators of compromise against internal assets</p>
      </motion.div>

      <motion.div variants={fadeIn} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search IOCs by indicator or type..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-gray-900 text-white pl-12 pr-4 py-3 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </motion.div>

      <motion.div variants={fadeIn} className="space-y-4">
        {filtered.map((ioc) => (
          <motion.div
            key={ioc.id}
            whileHover={{ scale: 1.01 }}
            className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-gray-600 transition-colors"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-xl font-semibold text-white font-mono">{ioc.indicator}</h3>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-500/20 text-blue-400">
                    {ioc.type}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRiskColor(ioc.risk)}`}>
                    {ioc.risk} Risk
                  </span>
                </div>
                <p className="text-gray-400 mb-3">{ioc.threatCategory}</p>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-400 mb-1">Confidence</div>
                <div className="text-2xl font-bold text-white">{ioc.confidence}%</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="bg-gray-900 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-2">Matched Assets</div>
                <div className="text-2xl font-bold text-white">{ioc.matchedAssets}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-2">Critical Assets</div>
                <div className="text-2xl font-bold text-orange-400">{ioc.criticalAssets}</div>
              </div>
              <div className="bg-gray-900 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-2">First Seen</div>
                <div className="text-sm font-medium text-white">{ioc.firstSeen}</div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-gray-700">
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-400">Source: <span className="text-white">{ioc.source}</span></span>
                <span className="text-sm text-gray-400">Last Seen: <span className="text-white">{ioc.lastSeen}</span></span>
              </div>
              <div className="flex space-x-2">
                <Button variant="ghost" size="sm">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Whitelist
                </Button>
                <Button variant="primary" size="sm">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Investigate
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default IOCCorrelation;