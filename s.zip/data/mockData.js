export const threatStats = {
  critical: 23,
  activeIOCs: 147,
  vulnerabilities: 56,
  riskScore: 78
};

export const agentStatus = [
  {
    id: 1,
    name: 'Threat Intelligence Agent',
    description: 'Monitoring external threat feeds and correlating IOCs',
    status: 'Active',
    confidence: 94
  },
  {
    id: 2,
    name: 'Vulnerability Scanner',
    description: 'Scanning infrastructure for CVE matches',
    status: 'Warning',
    confidence: 87
  },
  {
    id: 3,
    name: 'AI Risk Assessor',
    description: 'Analyzing threat patterns and business impact',
    status: 'Critical',
    confidence: 91
  }
];

export const recentThreats = [
  {
    id: 1,
    title: 'Ransomware Campaign Detected',
    category: 'Ransomware',
    severity: 'Critical',
    description: 'Multiple IOCs associated with LockBit 3.0 ransomware detected in network traffic',
    timestamp: '2 hours ago'
  },
  {
    id: 2,
    title: 'C2 Communication Attempt',
    category: 'Command & Control',
    severity: 'High',
    description: 'Suspicious outbound connection to known C2 infrastructure',
    timestamp: '4 hours ago'
  },
  {
    id: 3,
    title: 'Phishing Campaign Targeting Employees',
    category: 'Phishing',
    severity: 'Medium',
    description: 'Email campaign with malicious attachments detected',
    timestamp: '6 hours ago'
  },
  {
    id: 4,
    title: 'Credential Stuffing Attack',
    category: 'Authentication',
    severity: 'High',
    description: 'Multiple failed login attempts from distributed sources',
    timestamp: '8 hours ago'
  },
  {
    id: 5,
    title: 'Malware Dropper Identified',
    category: 'Malware',
    severity: 'Critical',
    description: 'New variant of Emotet malware detected on endpoint',
    timestamp: '10 hours ago'
  },
  {
    id: 6,
    title: 'DDoS Attack Mitigated',
    category: 'Network',
    severity: 'Medium',
    description: 'Distributed denial of service attack successfully blocked',
    timestamp: '12 hours ago'
  }
];

export const threatFeeds = [
  {
    id: 1,
    name: 'AlienVault OTX',
    source: 'Open Threat Exchange',
    description: 'Community-driven threat intelligence platform providing real-time IOC updates',
    status: 'active',
    iocsToday: 1247,
    reliability: 94,
    lastUpdate: '5 minutes ago'
  },
  {
    id: 2,
    name: 'VirusTotal Intelligence',
    source: 'Google Chronicle',
    description: 'Malware and threat intelligence from file and URL analysis',
    status: 'active',
    iocsToday: 892,
    reliability: 98,
    lastUpdate: '10 minutes ago'
  },
  {
    id: 3,
    name: 'MISP Threat Sharing',
    source: 'MISP Project',
    description: 'Malware Information Sharing Platform with structured threat data',
    status: 'active',
    iocsToday: 634,
    reliability: 91,
    lastUpdate: '15 minutes ago'
  },
  {
    id: 4,
    name: 'AbuseIPDB',
    source: 'Abuse IP Database',
    description: 'Database of malicious IP addresses reported by users',
    status: 'warning',
    iocsToday: 423,
    reliability: 85,
    lastUpdate: '1 hour ago'
  },
  {
    id: 5,
    name: 'MalwareBazaar',
    source: 'abuse.ch',
    description: 'Repository of malware samples and associated IOCs',
    status: 'active',
    iocsToday: 312,
    reliability: 96,
    lastUpdate: '20 minutes ago'
  },
  {
    id: 6,
    name: 'Emerging Threats',
    source: 'Proofpoint',
    description: 'Real-time threat intelligence and IDS/IPS rules',
    status: 'error',
    iocsToday: 0,
    reliability: 92,
    lastUpdate: '3 hours ago'
  }
];

export const iocCorrelations = [
  {
    id: 1,
    indicator: '192.168.45.123',
    type: 'IP Address',
    threatCategory: 'Command & Control',
    risk: 'High',
    confidence: 89,
    matchedAssets: 3,
    criticalAssets: 1,
    firstSeen: '2024-01-15',
    lastSeen: '2 hours ago',
    source: 'AlienVault OTX'
  },
  {
    id: 2,
    indicator: 'malicious-domain.xyz',
    type: 'Domain',
    threatCategory: 'Phishing',
    risk: 'Medium',
    confidence: 76,
    matchedAssets: 7,
    criticalAssets: 0,
    firstSeen: '2024-01-18',
    lastSeen: '5 hours ago',
    source: 'VirusTotal'
  },
  {
    id: 3,
    indicator: 'a3f5d8c9e1b2f4a6c8d0e2f4a6b8c0d2',
    type: 'File Hash (MD5)',
    threatCategory: 'Ransomware',
    risk: 'High',
    confidence: 95,
    matchedAssets: 1,
    criticalAssets: 1,
    firstSeen: '2024-01-20',
    lastSeen: '1 hour ago',
    source: 'MalwareBazaar'
  },
  {
    id: 4,
    indicator: 'hxxp://evil-site[.]com/payload',
    type: 'URL',
    threatCategory: 'Malware Distribution',
    risk: 'High',
    confidence: 92,
    matchedAssets: 2,
    criticalAssets: 0,
    firstSeen: '2024-01-19',
    lastSeen: '3 hours ago',
    source: 'MISP'
  },
  {
    id: 5,
    indicator: '10.0.45.67',
    type: 'IP Address',
    threatCategory: 'Botnet',
    risk: 'Medium',
    confidence: 71,
    matchedAssets: 5,
    criticalAssets: 2,
    firstSeen: '2024-01-17',
    lastSeen: '6 hours ago',
    source: 'AbuseIPDB'
  },
  {
    id: 6,
    indicator: 'suspicious-app.exe',
    type: 'Filename',
    threatCategory: 'Trojan',
    risk: 'Low',
    confidence: 68,
    matchedAssets: 1,
    criticalAssets: 0,
    firstSeen: '2024-01-21',
    lastSeen: '8 hours ago',
    source: 'Internal IOC List'
  }
];

export const vulnerabilities = [
  {
    id: 1,
    cveId: 'CVE-2024-1234',
    description: 'Critical remote code execution vulnerability in Apache Log4j allowing unauthenticated attackers to execute arbitrary code',
    severity: 'Critical',
    cvssScore: 9.8,
    affectedAssets: 23,
    vendor: 'Apache',
    product: 'Log4j',
    publishedDate: '2024-01-15',
    exploitAvailable: true,
    patchAvailable: true
  },
  {
    id: 2,
    cveId: 'CVE-2024-5678',
    description: 'Privilege escalation vulnerability in Windows kernel allowing local attackers to gain SYSTEM privileges',
    severity: 'High',
    cvssScore: 7.8,
    affectedAssets: 47,
    vendor: 'Microsoft',
    product: 'Windows Server 2019',
    publishedDate: '2024-01-18',
    exploitAvailable: false,
    patchAvailable: true
  },
  {
    id: 3,
    cveId: 'CVE-2024-9012',
    description: 'SQL injection vulnerability in web application framework allowing data exfiltration',
    severity: 'High',
    cvssScore: 8.2,
    affectedAssets: 12,
    vendor: 'Custom',
    product: 'Internal Web App',
    publishedDate: '2024-01-20',
    exploitAvailable: true,
    patchAvailable: false
  },
  {
    id: 4,
    cveId: 'CVE-2024-3456',
    description: 'Cross-site scripting vulnerability in popular CMS allowing session hijacking',
    severity: 'Medium',
    cvssScore: 6.1,
    affectedAssets: 8,
    vendor: 'WordPress',
    product: 'WordPress Core',
    publishedDate: '2024-01-19',
    exploitAvailable: false,
    patchAvailable: true
  },
  {
    id: 5,
    cveId: 'CVE-2024-7890',
    description: 'Information disclosure vulnerability in SSL/TLS implementation',
    severity: 'Low',
    cvssScore: 4.3,
    affectedAssets: 34,
    vendor: 'OpenSSL',
    product: 'OpenSSL 1.1.1',
    publishedDate: '2024-01-17',
    exploitAvailable: false,
    patchAvailable: true
  }
];

export const aiRecommendations = [
  {
    id: 1,
    title: 'Isolate Compromised Host 192.168.45.123',
    description: 'AI detected high-confidence C2 communication from critical database server. Immediate isolation recommended to prevent lateral movement.',
    priority: 'Critical',
    confidence: 94,
    impact: 'Prevents potential data exfiltration and lateral movement to other critical systems',
    effort: '15 minutes',
    reasoning: 'The IOC 192.168.45.123 has been correlated with known C2 infrastructure from multiple threat intelligence feeds. Network telemetry shows sustained outbound connections to this IP from a database server containing sensitive customer data. Historical patterns indicate this behavior precedes ransomware deployment in 87% of similar cases.',
    actions: [
      'Immediately isolate host DB-PROD-01 from network',
      'Capture memory dump for forensic analysis',
      'Review recent authentication logs for compromised credentials',
      'Scan all connected systems for similar IOC patterns'
    ],
    requiresApproval: true
  },
  {
    id: 2,
    title: 'Block Malicious Domain at Firewall',
    description: 'Multiple endpoints attempting to resolve malicious-domain.xyz associated with active phishing campaign.',
    priority: 'High',
    confidence: 87,
    impact: 'Blocks potential malware downloads and credential theft attempts',
    effort: '10 minutes',
    reasoning: 'The domain malicious-domain.xyz has been identified in 7 DNS queries from different endpoints over the past 6 hours. VirusTotal intelligence confirms this domain is hosting phishing pages mimicking our corporate login portal. Email logs show 23 employees received messages containing links to this domain.',
    actions: [
      'Add domain to firewall block list',
      'Configure DNS sinkhole for this domain',
      'Send security awareness alert to affected users',
      'Review email gateway for similar campaigns'
    ],
    requiresApproval: false
  },
  {
    id: 3,
    title: 'Urgent Patching Required for CVE-2024-1234',
    description: 'Critical Log4j vulnerability detected on 23 production servers with active exploit code available.',
    priority: 'Critical',
    confidence: 98,
    impact: 'Eliminates critical remote code execution risk on production infrastructure',
    effort: '2-4 hours',
    reasoning: 'CVE-2024-1234 affects Apache Log4j libraries used across 23 production servers. Public exploit code is actively being used in the wild according to threat intelligence feeds. Asset criticality analysis shows 15 of these servers process sensitive financial transactions. The vulnerability allows unauthenticated remote code execution with CVSS score of 9.8.',
    actions: [
      'Schedule emergency maintenance window',
      'Apply vendor patches to all affected systems',
      'Implement temporary WAF rules as mitigation',
      'Conduct post-patch vulnerability validation',
      'Review logs for exploitation attempts'
    ],
    requiresApproval: true
  },
  {
    id: 4,
    title: 'Enhance Monitoring for Credential Stuffing',
    description: 'AI detected pattern consistent with credential stuffing attack across authentication systems.',
    priority: 'Medium',
    confidence: 82,
    impact: 'Improves detection of account compromise attempts and reduces false negatives',
    effort: '30 minutes',
    reasoning: 'Analysis of authentication logs reveals 1,247 failed login attempts from 89 unique IP addresses over 3 hours, targeting 156 user accounts. The attack pattern shows low-and-slow characteristics designed to evade rate limiting. Threat intelligence indicates this matches the TTPs of the APT group tracked as Storm-0324.',
    actions: [
      'Implement stricter rate limiting on authentication endpoints',
      'Enable multi-factor authentication for targeted accounts',
      'Configure SIEM alerts for distributed failed login patterns',
      'Force password reset for accounts with multiple failed attempts'
    ],
    requiresApproval: false
  },
  {
    id: 5,
    title: 'Investigate Anomalous Data Transfer',
    description: 'Unusual large data transfer detected from file server to external cloud storage.',
    priority: 'High',
    confidence: 79,
    impact: 'Identifies potential data exfiltration before significant data loss occurs',
    effort: '45 minutes',
    reasoning: 'Network monitoring detected 47GB of data transferred from FILE-SRV-02 to an external cloud storage service over 6 hours during off-peak hours. The user account associated with this transfer typically averages 200MB daily uploads. Behavioral analysis indicates this is 235x above normal baseline and coincides with access to sensitive project folders.',
    actions: [
      'Review user activity logs for FILE-SRV-02',
      'Verify legitimacy of cloud storage destination',
      'Interview account owner about transfer activity',
      'Implement DLP policy to prevent unauthorized transfers',
      'Audit file access permissions on sensitive directories'
    ],
    requiresApproval: false
  }
];
