# TIA UI (Vite + React)

Quick scaffold so the existing React components run with Vite and Tailwind.

Steps to run (PowerShell):

```powershell
# 1) install dependencies
npm install

# 2) start dev server
npm run dev
```

Notes:
- This workspace uses Tailwind CSS and React Router; `package.json` includes the necessary packages.
- If you already have a global setup or want to use `pnpm`/`yarn`, adapt the commands accordingly.
