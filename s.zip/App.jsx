import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import Dashboard from './pages/Dashboard';
import ThreatFeeds from './pages/ThreatFeeds';
import IOCCorrelation from './pages/IOCCorrelation';
import VulnerabilityIntel from './pages/VulnerabilityIntel';
import Recommendations from './pages/Recommendations';

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-900 text-gray-100">
        <NavBar />
        <main className="container mx-auto px-4 py-6 max-w-7xl">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/threat-feeds" element={<ThreatFeeds />} />
            <Route path="/ioc-correlation" element={<IOCCorrelation />} />
            <Route path="/vulnerability-intel" element={<VulnerabilityIntel />} />
            <Route path="/recommendations" element={<Recommendations />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;