import os
import time
import json
import logging
from datetime import datetime
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# =========================================================
# Optional .env loading
# =========================================================
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# =========================================================
# Logging
# =========================================================
LOG = logging.getLogger("fetch_iocs")
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# =========================================================
# Environment config
# =========================================================
OTX_URL = os.getenv("OTX_URL", "https://otx.alienvault.com/api/v1/indicators/export")
OTX_API_KEY = "e433b378b468a02fc0b5d6b1ce053b1e8ec6f376b9e1ad02912439f5ff469a65"

ABUSEIPDB_URL = os.getenv("ABUSEIPDB_URL", "https://api.abuseipdb.com/api/v2/blacklist")
ABUSEIPDB_API_KEY = os.getenv("ABUSEIPDB_API_KEY", "")

NVD_URL = os.getenv("NVD_URL", "https://services.nvd.nist.gov/rest/json/cves/2.0")
NVD_API_KEY = os.getenv("NVD_API_KEY", "")

# =========================================================
# HTTP session with retry/backoff
# =========================================================
def build_session():
    s = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=(429, 500, 502, 503, 504),
        raise_on_status=False
    )
    s.mount("https://", HTTPAdapter(max_retries=retry))
    s.mount("http://", HTTPAdapter(max_retries=retry))
    return s

# =========================================================
# Helpers
# =========================================================
def normalize_type(t):
    if not t:
        return ""
    t = t.lower()
    if "ipv4" in t or "ipv6" in t or t == "ip":
        return "IP"
    if "domain" in t or "hostname" in t:
        return "DOMAIN"
    if "url" in t:
        return "URL"
    if "hash" in t or "file":
        return "HASH"
    if "cve" in t:
        return "CVE"
    return t.upper()

def parse_timestamp(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).isoformat()
    except Exception:
        return s

# =========================================================
# OTX FETCH (MANDATORY types parameter)
# =========================================================
def fetch_otx(session):
    headers = {}
    if OTX_API_KEY:
        headers["X-OTX-API-KEY"] = OTX_API_KEY

    # 🚨 REQUIRED FOR EXPORT TO RETURN DATA
    params = {
        "types": "IPv4,domain,hostname,url,FileHash-MD5,FileHash-SHA256",
        "limit": 100
    }

    LOG.info("OTX request params: %s", params)

    iocs = []

    try:
        resp = session.get(
            OTX_URL,
            headers=headers,
            params=params,
            timeout=(5, 30)
        )

        if resp.status_code == 429:
            ra = resp.headers.get("Retry-After")
            LOG.warning("OTX rate limited. Retry-After=%s", ra)
            return []

        resp.raise_for_status()
        raw = resp.text.strip()

        objects = []

        # Format A: NDJSON
        if "\n" in raw:
            for line in raw.splitlines():
                try:
                    objects.append(json.loads(line))
                except Exception:
                    continue
        else:
            # Format B: JSON with results
            try:
                body = json.loads(raw)
                if isinstance(body, dict) and "results" in body:
                    objects = body["results"]
                else:
                    objects = [body]
            except Exception:
                pass

        for obj in objects:
            value = obj.get("indicator")
            if not value:
                continue

            iocs.append({
                "ioc_type": normalize_type(obj.get("type")),
                "value": value,
                "confidence": int(obj.get("confidence") or 50),
                "category": obj.get("type"),
                "source": "alienvault_otx",
                "last_seen": parse_timestamp(obj.get("created") or obj.get("modified"))
            })

        if not iocs:
            LOG.warning("OTX returned HTTP 200 but produced 0 indicators")

        return iocs

    except Exception as e:
        LOG.error("OTX fetch failed: %s", e)
        return []

# =========================================================
# AbuseIPDB FETCH (FREE TIER SAFE)
# =========================================================
def fetch_abuseipdb(session):
    if not ABUSEIPDB_API_KEY:
        LOG.warning("AbuseIPDB API key missing — skipping feed")
        return []

    headers = {
        "Key": ABUSEIPDB_API_KEY,
        "Accept": "application/json"
    }

    params = {
        "confidenceMinimum": 90
    }

    try:
        resp = session.get(
            ABUSEIPDB_URL,
            headers=headers,
            params=params,
            timeout=(5, 20)
        )

        if resp.status_code == 401:
            LOG.warning("AbuseIPDB unauthorized (401) — invalid key")
            return []

        if resp.status_code == 429:
            LOG.warning("AbuseIPDB rate limited (free tier)")
            return []

        resp.raise_for_status()
        data = resp.json().get("data", [])

        return [{
            "ioc_type": "IP",
            "value": row["ipAddress"],
            "confidence": int(row.get("abuseConfidenceScore") or 0),
            "category": "abuse-ip",
            "source": "abuseipdb",
            "last_seen": parse_timestamp(row.get("lastReportedAt"))
        } for row in data if row.get("ipAddress")]

    except Exception as e:
        LOG.error("AbuseIPDB fetch failed: %s", e)
        return []

# =========================================================
# NVD FETCH
# =========================================================
def fetch_nvd(session, max_pages=1):
    headers = {}
    if NVD_API_KEY:
        headers["apiKey"] = NVD_API_KEY

    iocs = []

    try:
        for page in range(max_pages):
            params = {
                "resultsPerPage": 100,
                "startIndex": page * 100
            }

            resp = session.get(
                NVD_URL,
                headers=headers,
                params=params,
                timeout=(5, 30)
            )

            if resp.status_code == 429:
                LOG.warning("NVD rate limited")
                return []

            resp.raise_for_status()
            vulns = resp.json().get("vulnerabilities", [])

            for item in vulns:
                cve = item.get("cve", {})
                cid = cve.get("id")
                if not cid:
                    continue

                iocs.append({
                    "ioc_type": "CVE",
                    "value": cid,
                    "confidence": 80,
                    "category": "vulnerability",
                    "source": "nvd",
                    "last_seen": parse_timestamp(cve.get("lastModified"))
                })

            if len(vulns) < 100:
                break

        return iocs

    except Exception as e:
        LOG.error("NVD fetch failed: %s", e)
        return []

# =========================================================
# Health check
# =========================================================
def health_check(name, iocs, minimum):
    if len(iocs) < minimum:
        LOG.warning("FEED HEALTH WARNING: %s returned %d IOCs", name, len(iocs))

# =========================================================
# Main
# =========================================================
def main():
    session = build_session()

    LOG.info("Fetching AlienVault OTX…")
    otx_iocs = fetch_otx(session)

    LOG.info("Fetching AbuseIPDB…")
    abuse_iocs = fetch_abuseipdb(session)

    LOG.info("Fetching NVD…")
    nvd_iocs = fetch_nvd(session)

    health_check("OTX", otx_iocs, 10)
    health_check("AbuseIPDB", abuse_iocs, 1)
    health_check("NVD", nvd_iocs, 1)

    all_iocs = {
        "alienvault_otx": otx_iocs,
        "abuseipdb": abuse_iocs,
        "nvd": nvd_iocs
    }

    for k, v in all_iocs.items():
        LOG.info("%s: fetched %d IOCs", k, len(v))

    out = os.getenv("FETCH_IOCS_OUT", "fetched_iocs.json")
    LOG.info("Writing output to %s", out)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(all_iocs, f, indent=2)

if __name__ == "__main__":
    main()
