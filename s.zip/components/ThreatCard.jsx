import { motion } from 'framer-motion';
import { AlertCircle, Clock } from 'lucide-react';
import Button from './Button';

const ThreatCard = ({ threat }) => {
  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'Critical': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'High': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default: return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-gray-600 transition-colors"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-semibold text-white">{threat.title}</h3>
            <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(threat.severity)}`}>
              {threat.severity}
            </span>
          </div>
          <p className="text-sm text-gray-400">{threat.category}</p>
        </div>
      </div>
      
      <p className="text-gray-300 text-sm mb-4">{threat.description}</p>
      
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center space-x-2 text-gray-400">
          <Clock className="w-4 h-4" />
          <span>{threat.timestamp}</span>
        </div>
        <Button variant="ghost" size="sm">
          <AlertCircle className="w-4 h-4 mr-2" />
          Investigate
        </Button>
      </div>
    </motion.div>
  );
};

export default ThreatCard;