import { motion } from 'framer-motion';
import { fadeIn } from '../utils/motion';

const StatCard = ({ title, value, icon: Icon, color, trend }) => {
  const colors = {
    red: 'text-red-400 bg-red-500/20',
    orange: 'text-orange-400 bg-orange-500/20',
    yellow: 'text-yellow-400 bg-yellow-500/20',
    blue: 'text-blue-400 bg-blue-500/20',
  };

  return (
    <motion.div
      variants={fadeIn}
      whileHover={{ scale: 1.05 }}
      className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-gray-600 transition-colors"
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colors[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
        {trend && (
          <span className={`text-sm font-medium ${
            trend.startsWith('+') ? 'text-green-400' : 'text-red-400'
          }`}>
            {trend}
          </span>
        )}
      </div>
      <div className="text-3xl font-bold text-white mb-1">{value}</div>
      <div className="text-sm text-gray-400">{title}</div>
    </motion.div>
  );
};

export default StatCard;