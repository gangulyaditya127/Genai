from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.api.router import api_router
from app.mcp_client.client import init_mcp_client

app = FastAPI(title="Agentic Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    # init OpenAI client, DB, MCP client, agents etc.
    await init_mcp_client()
    # any other startup hooks

app.include_router(api_router)
