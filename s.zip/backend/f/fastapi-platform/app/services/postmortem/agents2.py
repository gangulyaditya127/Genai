# app/services/postmortem/agents.py
import openai
from agents.mcp import MCPServerSse, create_static_tool_filter
from agents import Agent, ModelSettings, OpenAIChatCompletionsModel, set_default_openai_client
from app.core.config import settings

mcp_server = None
init_agent = None
qa_agent = None

async def init_postmortem_agents():
    global mcp_server, init_agent, qa_agent

    if mcp_server is None:
        mcp_server = MCPServerSse(
            {"url": settings.MCP_SERVER_URL},
            client_session_timeout_seconds=60,
            tool_filter=create_static_tool_filter(
                allowed_tool_names=["fetch_incident_details"]
            ),
        )
        await mcp_server.connect()

    client = openai.AsyncOpenAI(
        api_key=settings.OPENAI_API_KEY,
        base_url=settings.OPENAI_BASE_URL,
    )
    set_default_openai_client(client=client)

    init_agent = Agent(
        name="Postmortem Init Agent",
        instructions=INIT_AGENT_PROMPT,
        output_type=str,
        model_settings=ModelSettings(tool_choice="fetch_incident_details"),
        model=OpenAIChatCompletionsModel(model="GPT-4o", openai_client=client),
        mcp_servers=[mcp_server],
    )

    qa_agent = Agent(
        name="Postmortem QA Agent",
        instructions=QA_AGENT_PROMPT2,
        output_type=str,
        model_settings=ModelSettings(tool_choice="none"),
        model=OpenAIChatCompletionsModel(model="GPT-4o", openai_client=client),
        mcp_servers=[mcp_server],
    )
