import json
import openai
from agents import Agent, ModelSettings, OpenAIChatCompletionsModel, set_default_openai_client
from app.core.config import settings
from app.mcp_client.client import mcp_server

# setup OpenAI
client = openai.AsyncOpenAI(
    api_key=settings.OPENAI_API_KEY,
    base_url=settings.OPENAI_BASE_URL,
)
set_default_openai_client(client=client)

INIT_AGENT_PROMPT = """..."""  # your existing string
QA_AGENT_PROMPT2 = """..."""

init_agent = None
qa_agent = None

def init_postmortem_agents():
    global init_agent, qa_agent

    init_agent = Agent(
        name="Postmortem Init Agent",
        instructions=INIT_AGENT_PROMPT,
        output_type=str,
        model_settings=ModelSettings(tool_choice="fetch_incident_details"),
        model=OpenAIChatCompletionsModel(model="GPT-4o", openai_client=client),
        mcp_servers=[mcp_server],
    )

    qa_agent = Agent(
        name="Postmortem QA Agent",
        instructions=QA_AGENT_PROMPT2,
        output_type=str,
        model_settings=ModelSettings(tool_choice="none"),
        model=OpenAIChatCompletionsModel(model="GPT-4o", openai_client=client),
        mcp_servers=[mcp_server],
    )
