@echo off
setlocal

echo ------------------------------------------
echo Creating FastAPI Platform Structure...
echo ------------------------------------------

:: 1. Create Root Directory
mkdir fastapi-platform
cd fastapi-platform

:: 2. Create Root Files
type nul > requirements.txt
type nul > README.md

:: 3. Create mcp_server folder and files
mkdir mcp_server
type nul > mcp_server\mcpserver.py
type nul > mcp_server\requirements.txt

:: 4. Create app folder
mkdir app
cd app

:: 5. Create app root files
type nul > main.py

:: 6. Create app/core
mkdir core
type nul > core\config.py
type nul > core\db.py
type nul > core\logging.py

:: 7. Create app/mcp_client
mkdir mcp_client
type nul > mcp_client\__init__.py
type nul > mcp_client\client.py

:: 8. Create app/common
mkdir common
type nul > common\models.py
type nul > common\schemas.py

:: 9. Create app/api
mkdir api
type nul > api\__init__.py
type nul > api\router.py

:: 10. Create app/services parent folder
mkdir services
cd services

:: 11. Create services/postmortem
mkdir postmortem
type nul > postmortem\__init__.py
type nul > postmortem\models.py
type nul > postmortem\schemas.py
type nul > postmortem\agents.py
type nul > postmortem\routes.py
type nul > postmortem\repository.py

:: 12. Create services/ams_analytics
mkdir ams_analytics
type nul > ams_analytics\__init__.py
type nul > ams_analytics\routes.py
type nul > ams_analytics\service.py

:: Return to original directory (optional, just to be clean)
cd ..\..\..

echo.
echo ------------------------------------------
echo Folder structure created successfully in:
echo %CD%\fastapi-platform
echo ------------------------------------------
pause