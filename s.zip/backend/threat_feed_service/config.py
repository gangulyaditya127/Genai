import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Load .env from project root (if present). This allows local env overrides.
env_path = Path(BASE_DIR) / '.env'
example_env = Path(BASE_DIR) / '.env.example'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)
elif example_env.exists():
    # load the example to provide defaults for development
    load_dotenv(dotenv_path=example_env)


class Config:
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "TF_SQLITE_URI", f"sqlite:///{os.path.join(BASE_DIR, 'threat_feed.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # How often (seconds) scheduler will poll feeds when started via app
    FEED_POLL_INTERVAL = int(os.environ.get("FEED_POLL_INTERVAL", 3))

    # Adapter-specific configurations collected into ADAPTER_CONFIGS
    ADAPTER_CONFIGS = {
        'alienvault_otx': {
            'url': os.environ.get('OTX_URL'),
            'api_key': os.environ.get('OTX_API_KEY'),
        },
        'abuseipdb': {
            'url': os.environ.get('ABUSEIPDB_URL'),
            'api_key': os.environ.get('ABUSEIPDB_API_KEY'),
            'max_items': os.environ.get('ABUSEIPDB_MAX_ITEMS', ''),
            'max_retries': os.environ.get('ABUSEIPDB_MAX_RETRIES', '1'),
            'confidence_minimum': os.environ.get('ABUSEIPDB_CONFIDENCE_MINIMUM', '80'),
        },
        'nvd': {
            'url': os.environ.get('NVD_URL'),
        },
    }

