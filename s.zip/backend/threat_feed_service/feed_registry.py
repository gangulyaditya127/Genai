"""Registry for feed adapters so core logic can iterate without coupling."""

from typing import Dict


class FeedRegistry:
    def __init__(self):
        # mapping name -> adapter instance
        self._adapters: Dict[str, object] = {}

    def register(self, adapter):
        """Register an adapter instance. Adapter must have a unique `name` attribute."""
        if getattr(adapter, "name", None) in self._adapters:
            raise ValueError(f"Adapter with name {adapter.name} already registered")
        self._adapters[adapter.name] = adapter

    def adapters(self):
        """Return registered adapter instances."""
        return list(self._adapters.values())


# global registry used by startup code to register available adapters
registry = FeedRegistry()
