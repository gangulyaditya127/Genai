from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


def init_db(app):
    """Initialize the SQLAlchemy DB with the Flask app and create tables."""
    db.init_app(app)
    with app.app_context():
        db.create_all()
