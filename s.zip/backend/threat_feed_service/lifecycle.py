from datetime import datetime, timedelta
from db import db
from models import IOC


def expire_old_iocs(days: int = 30):
    """Mark IOCs inactive when last_seen is older than `days` days.

    Expired IOCs remain in DB but have `active = False`.
    """
    cutoff = datetime.utcnow() - timedelta(days=days)
    # Use a transaction context; SQLAlchemy will commit on successful exit.
    with db.session.begin():
        q = db.session.query(IOC).filter(IOC.last_seen < cutoff, IOC.active == True)
        for ioc in q:
            ioc.active = False
            db.session.add(ioc)
