"""Print per-adapter diagnostics (used_fallback, last_response_status, last_response_preview truncated, last_error).

This is a focused helper to run during local debugging; it intentionally prints concise diagnostics.
"""
import os
import sys
import json

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app import create_app
from feed_registry import registry
from feed_processor import process_all


def truncate(s, n=200):
    if not s:
        return None
    s = str(s)
    return s if len(s) <= n else s[:n] + '...'


def main():
    app = create_app()
    with app.app_context():
        adapters = registry.adapters()
        # run one processing pass to populate diagnostics
        process_all(registry, app=app)

        out = []
        for a in adapters:
            out.append({
                'name': getattr(a, 'name', repr(a)),
                'used_fallback': getattr(a, 'used_fallback', None),
                'last_response_status': getattr(a, 'last_response_status', None),
                'last_response_preview': truncate(getattr(a, 'last_response_preview', None), 300),
                'last_error': truncate(getattr(a, 'last_error', None), 300),
            })
        print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
