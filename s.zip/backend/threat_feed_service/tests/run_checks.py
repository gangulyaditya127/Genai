"""Quick runtime checks for config and adapters.

This script:
- creates the Flask app
- prints DB URI and adapter configs loaded from `.env`
- lists discovered adapters and their configs
- runs one feed processing cycle (uses adapters' fallback sample data)
- requests the `/api/threat-feeds/iocs` endpoint and prints the JSON response
"""
import os
import sys

# Ensure project root is on sys.path so imports like `import app` work when running
# this script from the `tests/` directory.
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app import create_app
from feed_registry import registry
from db import db
from normalization import normalize_ioc
from models import IOC
import json
from datetime import datetime, timezone


def main():
    app = create_app()
    with app.app_context():
        print('SQLALCHEMY_DATABASE_URI=', app.config.get('SQLALCHEMY_DATABASE_URI'))
        print('FEED_POLL_INTERVAL=', app.config.get('FEED_POLL_INTERVAL'))
        print('ADAPTER_CONFIGS=', app.config.get('ADAPTER_CONFIGS'))

        adapters = registry.adapters()
        print(f'Discovered {len(adapters)} adapters (pre-fetch):')
        for a in adapters:
            print('-', getattr(a, 'name', repr(a)), 'config=', getattr(a, 'config', None))

        # run a single processing pass per adapter and collect stats
        stats = []

        def _to_naive_utc(dt):
            if not dt:
                return None
            if dt.tzinfo is None:
                return dt
            return dt.astimezone(timezone.utc).replace(tzinfo=None)

        for a in adapters:
            adapter_stats = {'adapter': getattr(a, 'name', repr(a)), 'parsed': 0, 'inserted': 0, 'updated': 0, 'errors': 0}
            print('\nProcessing adapter:', adapter_stats['adapter'])
            try:
                try:
                    raw = a.fetch()
                except TypeError:
                    raw = a.fetch()
                parsed = a.parse(raw) if raw is not None else []
                adapter_stats['parsed'] = len(parsed)
                now = datetime.utcnow()
                with db.session.begin():
                    for raw_ioc in parsed:
                        try:
                            norm = normalize_ioc(raw_ioc)
                        except Exception:
                            adapter_stats['errors'] += 1
                            continue
                        norm_last = _to_naive_utc(norm.get('last_seen'))
                        with db.session.no_autoflush:
                            existing = db.session.query(IOC).filter_by(ioc_type=norm['ioc_type'], value=norm['value']).first()
                        if existing:
                            if norm_last and (existing.last_seen is None or norm_last > existing.last_seen):
                                existing.last_seen = norm_last
                            else:
                                existing.last_seen = now
                            # merge sources
                            old_sources = existing.sources or ''
                            new_sources = norm.get('sources', '') or ''
                            old_list = [s.strip() for s in old_sources.split(',') if s.strip()]
                            new_list = [s.strip() for s in new_sources.split(',') if s.strip()]
                            seen = set(s.lower() for s in old_list)
                            out_sources = list(old_list)
                            for s in new_list:
                                if s.lower() not in seen:
                                    seen.add(s.lower())
                                    out_sources.append(s)
                            existing.sources = ','.join(out_sources)
                            existing.confidence = max(existing.confidence or 0, norm.get('confidence', 0) or 0)
                            if norm.get('category'):
                                existing.category = norm.get('category')
                            existing.active = True
                            db.session.add(existing)
                            adapter_stats['updated'] += 1
                        else:
                            i = IOC(
                                ioc_type=norm['ioc_type'],
                                value=norm['value'],
                                confidence=norm.get('confidence', 0) or 0,
                                sources=norm.get('sources', '') or '',
                                category=norm.get('category'),
                                first_seen=norm_last or now,
                                last_seen=norm_last or now,
                                active=True,
                            )
                            db.session.add(i)
                            adapter_stats['inserted'] += 1
            except Exception as e:
                adapter_stats['errors'] += 1
                # propagate adapter diagnostics too
                print(' Adapter fetch/parse error:', getattr(a, 'last_error', str(e)))
            # show adapter diagnostics
            print('  used_fallback:', getattr(a, 'used_fallback', None))
            print('  last_response_status:', getattr(a, 'last_response_status', None))
            preview = getattr(a, 'last_response_preview', None)
            if preview:
                print('  last_response_preview:', (preview[:200] + '...') if len(preview) > 200 else preview)
            print('  last_error:', getattr(a, 'last_error', None))
            print('  stats:', adapter_stats)
            stats.append(adapter_stats)

        # summarize totals
        total_parsed = sum(s.get('parsed', 0) for s in stats)
        total_inserted = sum(s.get('inserted', 0) for s in stats)
        total_updated = sum(s.get('updated', 0) for s in stats)
        total_errors = sum(s.get('errors', 0) for s in stats)
        print('\nPer-adapter stats:')
        for s in stats:
            print(f" - {s['adapter']}: parsed={s['parsed']}, inserted={s['inserted']}, updated={s['updated']}, errors={s['errors']}")
        print(f"Totals: parsed={total_parsed}, inserted={total_inserted}, updated={total_updated}, errors={total_errors}")

        # query the API via test client and show active IOC count
        client = app.test_client()
        resp = client.get('/api/threat-feeds/iocs')
        try:
            data = resp.get_json()
        except Exception:
            data = resp.data.decode()
        print('API /api/threat-feeds/iocs response:')
        print(json.dumps(data, indent=2, default=str))


if __name__ == '__main__':
    main()
