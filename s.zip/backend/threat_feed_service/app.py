"""Flask application entrypoint for Threat Feed Service"""

from flask import Flask
from config import Config
from db import init_db
from feed_registry import registry
from routes.threat_feeds import bp as threat_feeds_bp
from routes.scheduler import bp as scheduler_bp

import pkgutil
import importlib
import os
from adapters.base import AdapterBase


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Init DB
    init_db(app)

    # Register routes
    app.register_blueprint(threat_feeds_bp)
    app.register_blueprint(scheduler_bp)

    # Auto-discover adapters
    adapters_pkg_path = os.path.join(os.path.dirname(__file__), 'adapters')
    if os.path.isdir(adapters_pkg_path):
        for _, name, _ in pkgutil.iter_modules([adapters_pkg_path]):
            try:
                module = importlib.import_module(f"adapters.{name}")
            except Exception as e:
                print(f">>> Failed to import adapter module {name}: {e}")
                continue

            for attr in dir(module):
                obj = getattr(module, attr)
                if (
                    isinstance(obj, type)
                    and issubclass(obj, AdapterBase)
                    and obj is not AdapterBase
                ):
                    try:
                        registry.register(obj({}))
                        print(f">>> Registered adapter: {obj.name}")
                    except Exception as e:
                        print(f">>> Adapter register failed: {e}")

    print(f">>> Total adapters registered: {len(registry.adapters())}")

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(
        host="0.0.0.0",
        port=8000,
        debug=False,
        use_reloader=False
    )
