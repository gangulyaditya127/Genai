"""Adapter for AbuseIPDB (with retries, backoff, and result limiting)."""
from .base import AdapterBase
import requests
from datetime import datetime
import time


class AbuseIPDBAdapter(AdapterBase):
    name = 'abuseipdb'

    def __init__(self, config=None):
        super().__init__(config)
        self.url = self.config.get('url', 'https://api.abuseipdb.com/api/v2/blacklist')
        self.api_key = self.config.get('api_key')
        # maximum items to ingest in one pass (None = no limit)
        self.max_items = int(self.config.get('max_items')) if self.config.get('max_items') else None
        # how many retries to attempt on 429 or transient errors
        self.max_retries = int(self.config.get('max_retries', 3))

    def fetch(self, since=None):
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers['Key'] = self.api_key
        params = {}
        # allow configuration of confidenceMinimum; default to 50 to limit noise
        params['confidenceMinimum'] = int(self.config.get('confidence_minimum', 50))

        attempt = 0
        last_exc = None
        while attempt < self.max_retries:
            attempt += 1
            try:
                resp = requests.get(self.url, headers=headers, params=params, timeout=(5, 20))
                # capture status early for diagnostics
                self.last_response_status = resp.status_code
                if resp.status_code == 429:
                    # rate limited: check Retry-After header if present
                    ra = resp.headers.get('Retry-After')
                    try:
                        wait = int(ra) if ra else min(2 ** attempt, 60)
                    except Exception:
                        wait = min(2 ** attempt, 60)
                    time.sleep(wait)
                    last_exc = Exception(f'429 Too Many Requests (waited {wait}s)')
                    continue
                resp.raise_for_status()
                # mark that live fetch succeeded and capture diagnostics
                self.used_fallback = False
                try:
                    self.last_response_preview = resp.text[:500]
                except Exception:
                    self.last_response_preview = None
                return resp.json()
            except Exception as e:
                last_exc = e
                # transient network error: backoff and retry
                if attempt < self.max_retries:
                    time.sleep(min(2 ** attempt, 30))
                    continue
                # exhausted retries
                self.used_fallback = True
                self.last_error = str(last_exc)
                break

        # fallback sample (used when live fetch fails)
        return {'data': [
            {'ipAddress': '198.51.100.23', 'confidence': 85, 'categories': ['Malware'], 'lastReportedAt': datetime.utcnow().isoformat()},
            {'ipAddress': '203.0.113.45', 'confidence': 55, 'categories': ['Botnet'], 'lastReportedAt': datetime.utcnow().isoformat()},
        ]}

    def parse(self, raw):
        out = []
        data = raw.get('data', []) or []
        # apply max_items limiting if configured
        if self.max_items:
            data = data[:self.max_items]
        for it in data:
            value = it.get('ipAddress')
            # AbuseIPDB may return 'abuseConfidenceScore' or 'confidence' depending on endpoint
            confidence = it.get('abuseConfidenceScore') or it.get('confidence') or 0
            try:
                confidence = int(confidence)
            except Exception:
                try:
                    confidence = int(float(confidence))
                except Exception:
                    confidence = 0
            cats = it.get('categories') or []
            category = ','.join(cats) if cats else None
            out.append({
                'ioc_type': 'IP',
                'value': value,
                'confidence': confidence,
                'category': category,
                'source': self.name,
                'last_seen': it.get('lastReportedAt') or datetime.utcnow().isoformat(),
            })
        return out
