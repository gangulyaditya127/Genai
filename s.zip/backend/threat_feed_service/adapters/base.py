from abc import ABC, abstractmethod


class AdapterBase(ABC):
    """Abstract base class for feed adapters.

    Adapters must implement `fetch` and `parse`.

    - `fetch()` returns raw payload (adapter-specific)
    - `parse(payload)` returns a list of dicts with raw IOC fields
    """

    name = 'base'

    def __init__(self, config=None):
        self.config = config or {}

    @abstractmethod
    def fetch(self):
        """Fetch raw feed data. Return value is adapter-specific."""

    @abstractmethod
    def parse(self, raw):
        """Parse raw data and return iterable of raw IOC dicts.

        Each raw IOC dict should include at least: ioc_type, value, confidence (optional), category (optional), source (optional), last_seen (optional)
        """
