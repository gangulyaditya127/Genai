"""Adapter for NVD CVE feed (mocked/realistic structure).

This adapter extracts CVE IDs and maps them to IOC type CVE.
"""
from .base import AdapterBase
import requests
from datetime import datetime


class NVDAdapter(AdapterBase):
    name = 'nvd'

    def __init__(self, config=None):
        super().__init__(config)
        self.url = self.config.get('url', 'https://services.nvd.example/rest/json/cves/1.0')

    def fetch(self, since=None):
        api_key = self.config.get('api_key')
        headers = {}
        if api_key:
            headers['apiKey'] = api_key
        params = {'resultsPerPage': 100}
        if since:
            # NVD supports lastModStartDate/lastModEndDate in ISO format
            params['lastModStartDate'] = since.isoformat() if hasattr(since, 'isoformat') else str(since)
        try:
            resp = requests.get(self.url, headers=headers, params=params, timeout=(5,20))
            resp.raise_for_status()
            # mark that live fetch succeeded and capture diagnostics
            self.used_fallback = False
            self.last_response_status = resp.status_code
            try:
                self.last_response_preview = resp.text[:500]
            except Exception:
                self.last_response_preview = None
            return resp.json()
        except Exception as e:
            # mark that fallback sample data is being used and record error
            self.used_fallback = True
            self.last_error = str(e)
            # Return simple mocked CVE list
            return {'CVE_Items': [
                {'cve': {'CVE_data_meta': {'ID': 'CVE-2025-0001'}}, 'publishedDate': datetime.utcnow().isoformat(), 'cvss': {'baseScore': 7.5}},
                {'cve': {'CVE_data_meta': {'ID': 'CVE-2024-1234'}}, 'publishedDate': datetime.utcnow().isoformat(), 'cvss': {'baseScore': 5.0}},
            ]}

    def parse(self, raw):
        out = []
        for item in raw.get('CVE_Items', []):
            meta = item.get('cve', {}).get('CVE_data_meta', {})
            cve_id = meta.get('ID')
            last_seen = item.get('publishedDate')
            # try cvss
            cvss_obj = item.get('cvss') or {}
            score = cvss_obj.get('baseScore') or 0
            confidence = int(min(100, (float(score) / 10.0) * 100)) if score else 0
            out.append({
                'ioc_type': 'CVE',
                'value': cve_id,
                'confidence': confidence,
                'category': 'vulnerability',
                'source': self.name,
                'last_seen': last_seen or datetime.utcnow().isoformat(),
            })
        return out
