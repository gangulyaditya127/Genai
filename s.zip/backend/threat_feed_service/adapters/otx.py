"""Adapter for AlienVault OTX (mocked/realistic structure).

This adapter attempts to fetch from a configured URL. If network fails it returns an empty payload.
"""
from .base import AdapterBase
import requests
from datetime import datetime


class OTXAdapter(AdapterBase):
    name = 'alienvault_otx'

    def __init__(self, config=None):
        super().__init__(config)
        self.url = self.config.get('url', 'https://otx.alienvault.example/api/v1/indicators/export')
        self.api_key = self.config.get('api_key')

    def fetch(self, since=None):
        headers = {}
        if self.api_key:
            headers['X-OTX-API-KEY'] = self.api_key
        params = {}
        if since:
            # OTX supports modified_since (ISO8601)
            params['modified_since'] = since.isoformat() if hasattr(since, 'isoformat') else str(since)
        try:
            resp = requests.get(self.url, headers=headers, params=params or None, timeout=(5,20))
            resp.raise_for_status()
            # mark that live fetch succeeded and capture diagnostics
            self.used_fallback = False
            self.last_response_status = resp.status_code
            try:
                self.last_response_preview = resp.text[:500]
            except Exception:
                self.last_response_preview = None
            return resp.json()
        except Exception as e:
            # For portability, return a small realistic sample payload
            # mark that fallback sample data is being used and record error
            self.used_fallback = True
            self.last_error = str(e)
            return {
                'indicators': [
                    {'type': 'ip', 'indicator': '203.0.113.45', 'confidence': 75, 'pulse_info': {'name': 'malware-c2'}, 'last_seen': datetime.utcnow().isoformat()},
                    {'type': 'domain', 'indicator': 'bad.example.com', 'confidence': 60, 'pulse_info': {'name': 'phishing'}, 'last_seen': datetime.utcnow().isoformat()},
                ]
            }

    def parse(self, raw):
        out = []
        indicators = raw.get('indicators') or []
        for it in indicators:
            t = (it.get('type') or '').upper()
            mapping = {
                'IP': 'IP',
                'DOMAIN': 'DOMAIN',
                'URL': 'URL',
                'FILE': 'HASH',
            }
            ioc_type = mapping.get(t, t)
            value = it.get('indicator')
            confidence = it.get('confidence', 0)
            category = None
            pulse = it.get('pulse_info')
            if pulse and pulse.get('name'):
                category = pulse.get('name')
            out.append({
                'ioc_type': ioc_type,
                'value': value,
                'confidence': confidence,
                'category': category,
                'source': self.name,
                'last_seen': it.get('last_seen') or datetime.utcnow().isoformat(),
            })
        return out
