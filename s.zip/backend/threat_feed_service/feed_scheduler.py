"""Simple scheduler to poll feeds periodically in a background thread."""
import threading
import time
from datetime import datetime
from db import db
from lifecycle import expire_old_iocs
from feed_processor import process_adapter
from models import FeedState


def start_scheduler(registry, app, interval_seconds: int = 3600):
    """Start a background daemon thread that periodically runs feed processing and lifecycle.

    This function returns immediately. The background thread uses the Flask app context
    when running processing so that DB access works.
    """
    def _worker():
        with app.app_context():
            while True:
                for adapter in registry.adapters():
                    try:
                        # retrieve last_run for this adapter from DB
                        state = db.session.query(FeedState).filter_by(adapter_name=adapter.name).one_or_none()
                        last_run = state.last_run if state else None
                        # process adapter with optional since
                        process_adapter(adapter, since=last_run, app=app)

                        # update last_run on success
                        now = datetime.utcnow()
                        if state:
                            state.last_run = now
                        else:
                            state = FeedState(adapter_name=adapter.name, last_run=now)
                            db.session.add(state)
                        db.session.commit()
                    except Exception:
                        # rollback so subsequent adapters are not affected
                        try:
                            db.session.rollback()
                        except Exception:
                            pass
                try:
                    expire_old_iocs()
                except Exception:
                    pass
                time.sleep(interval_seconds)

    t = threading.Thread(target=_worker, daemon=True, name="feed-scheduler")
    t.start()
    return t


from datetime import datetime
from db import db
from feed_processor import process_adapter
from lifecycle import expire_old_iocs
from models import FeedState

def execute_feed_cycle(registry, app):
    print("\n>>> ENTERED execute_feed_cycle()")

    results = {
        "adapters_processed": [],
        "errors": []
    }

    with app.app_context():
        print(f">>> Total adapters registered: {len(registry.adapters())}")

        for adapter in registry.adapters():
            print("---------------------------------")
            print(f">>> Processing adapter: {adapter.name}")

            try:
                state = (
                    db.session.query(FeedState)
                    .filter_by(adapter_name=adapter.name)
                    .one_or_none()
                )
                last_run = state.last_run if state else None
                print(f">>> Last run for {adapter.name}: {last_run}")

                print(f">>> Calling process_adapter() for {adapter.name}")
                process_adapter(adapter, since=last_run, app=app)

                now = datetime.utcnow()
                if state:
                    state.last_run = now
                    print(f">>> Updated FeedState.last_run for {adapter.name}")
                else:
                    state = FeedState(
                        adapter_name=adapter.name,
                        last_run=now
                    )
                    db.session.add(state)
                    print(f">>> Created FeedState for {adapter.name}")

                # ✅ COMMIT ONLY FeedState change
                db.session.commit()
                print(f">>> FeedState commit successful for {adapter.name}")

                results["adapters_processed"].append(adapter.name)

            except Exception as e:
                print(f">>> ERROR processing {adapter.name}: {e}")
                try:
                    db.session.rollback()
                except Exception:
                    pass

                results["errors"].append({
                    "adapter": adapter.name,
                    "error": str(e)
                })

        print(">>> Running IOC lifecycle cleanup")
        try:
            expire_old_iocs()
            print(">>> IOC lifecycle cleanup completed")
        except Exception as e:
            print(f">>> ERROR during IOC cleanup: {e}")
            results["errors"].append({
                "lifecycle": str(e)
            })

    print(">>> EXITING execute_feed_cycle()\n")
    return results
