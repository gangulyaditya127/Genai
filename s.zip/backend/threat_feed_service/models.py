from datetime import datetime
from db import db


class IOC(db.Model):
    __tablename__ = "iocs"

    id = db.Column(db.Integer, primary_key=True)
    ioc_type = db.Column(db.String(16), nullable=False)
    value = db.Column(db.String(512), nullable=False, index=True)
    confidence = db.Column(db.Integer, nullable=False, default=0)
    sources = db.Column(db.String(1024), nullable=False, default="")
    category = db.Column(db.String(64), nullable=True)
    first_seen = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    last_seen = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    active = db.Column(db.Boolean, nullable=False, default=True)

    __table_args__ = (
        db.UniqueConstraint('ioc_type', 'value', name='uix_ioc_type_value'),
    )

    def to_dict_for_ui(self):
        """Return the fields required by the UI JSON contract."""
        return {
            "ioc_type": self.ioc_type,
            "value": self.value,
            "category": self.category,
            "confidence": self.confidence,
            "sources": self.sources,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None,
        }


class FeedState(db.Model):
    """Per-adapter persistent state for incremental ingestion.

    Stores the last successful run time for each adapter so incremental
    fetches can request only newer data.
    """
    __tablename__ = 'feed_states'

    id = db.Column(db.Integer, primary_key=True)
    adapter_name = db.Column(db.String(128), unique=True, nullable=False, index=True)
    last_run = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f"<FeedState {self.adapter_name} last_run={self.last_run}>"
