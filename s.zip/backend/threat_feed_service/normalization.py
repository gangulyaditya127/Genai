"""Normalization helpers for IOCs.

Convert feed-specific IOC representations into canonical forms.
"""
from urllib.parse import urlparse, urlunparse
import ipaddress
from datetime import datetime
from dateutil import parser as dateparser


def _normalize_sources(sources):
    """Normalize sources to a deduplicated, comma-separated string."""
    if not sources:
        return ""
    if isinstance(sources, str):
        parts = [s.strip() for s in sources.split(',') if s.strip()]
    elif isinstance(sources, (list, tuple, set)):
        parts = [str(s).strip() for s in sources if s]
    else:
        parts = [str(sources).strip()]
    # dedupe while preserving order
    seen = set()
    out = []
    for p in parts:
        if p.lower() not in seen:
            seen.add(p.lower())
            out.append(p)
    return ",".join(out)


def normalize_ioc(raw: dict) -> dict:
    """Normalize a raw IOC dict returned by adapters into canonical fields.

    Expected raw keys (adapter-dependent):
      - ioc_type: str (IP, DOMAIN, HASH, URL, CVE)
      - value: raw string
      - confidence: numeric (0-100)
      - category: optional
      - source: adapter name or feed identifier
      - last_seen: datetime string or datetime
    Returns a normalized dict with keys: ioc_type, value, confidence(int), category, sources(str), last_seen(datetime)
    """
    ioc_type = (raw.get('ioc_type') or '').strip().upper()
    value = raw.get('value')
    if not value:
        raise ValueError('IOC missing value')
    value = value.strip()

    # normalize by type
    if ioc_type == 'IP':
        # normalize to canonical IP string
        try:
            ip = ipaddress.ip_address(value)
            value = ip.exploded if ip.version == 6 else ip.compressed
        except Exception:
            # keep original if parse fails
            value = value
    elif ioc_type == 'DOMAIN':
        value = value.strip().lower().rstrip('.')
    elif ioc_type == 'HASH':
        value = value.strip().lower()
    elif ioc_type == 'URL':
        # normalize URL to scheme://netloc/path?query (no fragment)
        parsed = urlparse(value)
        scheme = parsed.scheme or 'http'
        netloc = parsed.netloc.lower()
        path = parsed.path or '/'
        value = urlunparse((scheme, netloc, path, '', parsed.query, ''))
    elif ioc_type == 'CVE':
        value = value.strip().upper()
    else:
        # unknown type: preserve as-is but uppercase type
        ioc_type = ioc_type or 'UNKNOWN'
        value = value.strip()

    # confidence
    conf = raw.get('confidence', 0)
    try:
        conf = int(conf)
    except Exception:
        try:
            conf = int(float(conf))
        except Exception:
            conf = 0
    if conf < 0:
        conf = 0
    if conf > 100:
        conf = 100

    # category
    category = raw.get('category')
    if category:
        category = str(category).strip().lower()

    # sources
    src = raw.get('source') or raw.get('sources')
    sources = _normalize_sources(src)

    # last_seen
    ls = raw.get('last_seen')
    if isinstance(ls, datetime):
        last_seen = ls
    else:
        try:
            last_seen = dateparser.parse(ls) if ls else datetime.utcnow()
        except Exception:
            last_seen = datetime.utcnow()

    return {
        'ioc_type': ioc_type,
        'value': value,
        'confidence': conf,
        'category': category,
        'sources': sources,
        'last_seen': last_seen,
    }
