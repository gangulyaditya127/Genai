from datetime import datetime
from db import db
from models import FeedState
from feed_processor import process_adapter
from lifecycle import expire_old_iocs


def execute_feed_cycle(registry):
    print("\n>>> EXECUTING FEED CYCLE")
    results = {"processed": [], "errors": []}

    for adapter in registry.adapters():
        print("----------------------------------")
        print(f">>> Processing adapter: {adapter.name}")

        try:
            state = (
                db.session.query(FeedState)
                .filter_by(adapter_name=adapter.name)
                .one_or_none()
            )
            last_run = state.last_run if state else None

            process_adapter(adapter, since=last_run)

            now = datetime.utcnow()
            if state:
                state.last_run = now
            else:
                db.session.add(
                    FeedState(adapter_name=adapter.name, last_run=now)
                )

            db.session.commit()
            print(f">>> Adapter {adapter.name} completed")

            results["processed"].append(adapter.name)

        except Exception as e:
            print(f">>> ERROR in {adapter.name}: {e}")
            db.session.rollback()
            results["errors"].append({adapter.name: str(e)})

    try:
        expire_old_iocs()
        print(">>> IOC lifecycle cleanup done")
    except Exception as e:
        print(f">>> Lifecycle error: {e}")

    print(">>> FEED CYCLE COMPLETED\n")
    return results
