from datetime import datetime, timezone
from db import db
from models import IOC
from sqlalchemy.exc import IntegrityError
from normalization import normalize_ioc


def _merge_sources(old, new):
    if not old:
        return new or ""
    if not new:
        return old or ""
    s = set(old.split(","))
    s.update(new.split(","))
    return ",".join(sorted(s))


def process_adapter(adapter, since=None):
    print(f">>> Fetching data from {adapter.name}, since={since}")

    raw = adapter.fetch(since=since)
    parsed = adapter.parse(raw)
    now = datetime.utcnow()

    for raw_ioc in parsed:
        try:
            norm = normalize_ioc(raw_ioc)
        except Exception:
            continue

        try:
            with db.session.begin_nested():
                ioc = IOC(
                    ioc_type=norm["ioc_type"],
                    value=norm["value"],
                    confidence=norm.get("confidence", 0),
                    sources=norm.get("sources", ""),
                    category=norm.get("category"),
                    first_seen=now,
                    last_seen=now,
                    active=True,
                )
                db.session.add(ioc)
                db.session.flush()

        except IntegrityError:
            existing = (
                db.session.query(IOC)
                .filter_by(
                    ioc_type=norm["ioc_type"],
                    value=norm["value"],
                )
                .with_for_update()
                .first()
            )
            if existing:
                existing.last_seen = now
                existing.sources = _merge_sources(
                    existing.sources, norm.get("sources", "")
                )
                existing.confidence = max(
                    existing.confidence, norm.get("confidence", 0)
                )
                existing.active = True
                db.session.add(existing)
