from flask import Blueprint, jsonify
from models import IOC
from db import db

bp = Blueprint('threat_feeds', __name__)


@bp.route('/api/threat-feeds/iocs', methods=['GET'])
def get_active_iocs():
    """Return active IOCs for UI.

    Only fields required by the UI are returned; internal DB-only fields are omitted.
    """
    q = db.session.query(IOC).filter(IOC.active == True)
    out = [ioc.to_dict_for_ui() for ioc in q.order_by(IOC.last_seen.desc()).all()]
    return jsonify({'iocs': out})
