from flask import Blueprint, jsonify
from feed_executor import execute_feed_cycle
from feed_registry import registry

bp = Blueprint("scheduler", __name__, url_prefix="/scheduler")


@bp.route("/run", methods=["POST"])
def run_scheduler():
    print("\n============================")
    print(">>> /scheduler/run CALLED")
    print("============================")

    result = execute_feed_cycle(registry)

    print(">>> /scheduler/run FINISHED")
    print("============================\n")

    return jsonify({
        "status": "completed",
        "result": result
    })
