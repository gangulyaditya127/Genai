import requests
import logging
from datetime import datetime, timezone
from typing import List, Dict, Any, Tuple

# ============================================================
# CONFIGURATION
# ============================================================

OTX_API_KEY = "e433b378b468a02fc0b5d6b1ce053b1e8ec6f376b9e1ad02912439f5ff469a65"
ABUSEIPDB_API_KEY = "2d8c949cf749e4eee535ad0a3df1be0d2f086debc05dbdd989ef71fee8c6ed52e2b65f10b6331380"

OTX_EXPORT_URL = "https://otx.alienvault.com/api/v1/indicators/export"
NVD_CVE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
ABUSEIPDB_URL = "https://api.abuseipdb.com/api/v2/blacklist"

REQUEST_TIMEOUT = 30

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
LOG = logging.getLogger("ThreatIntelAgent")

# ============================================================
# COMMON NORMALIZATION MODEL
# ============================================================

def normalize_ioc(
    source: str,
    ioc_type: str,
    value: str,
    confidence: int,
    tags: List[str],
    raw: Dict[str, Any]
) -> Dict[str, Any]:
    return {
        "source": source,
        "ioc_type": ioc_type,
        "value": value,
        "confidence": confidence,
        "tags": tags,
        "ingested_at": datetime.now(timezone.utc).isoformat(),
        "raw": raw
    }

# ============================================================
# OTX FEED
# ============================================================

# def fetch_otx_iocs(limit: int = 300) -> Tuple[List[Dict], Dict]:
#     status = {"source": "AlienVault OTX", "status": "active", "count": 0}
#     iocs = []

#     try:
#         headers = {"X-OTX-API-KEY": OTX_API_KEY}
#         params = {
#             "limit": limit,
#             "types": "IPv4,domain,hostname,url,filehash-md5,filehash-sha256"
#         }

#         r = requests.get(OTX_EXPORT_URL, headers=headers, params=params, timeout=REQUEST_TIMEOUT)
#         r.raise_for_status()

#         for line in r.text.splitlines():
#             parts = line.split("#")
#             if len(parts) < 2:
#                 continue

#             iocs.append(
#                 normalize_ioc(
#                     source="AlienVault OTX",
#                     ioc_type=parts[1],
#                     value=parts[0],
#                     confidence=90,
#                     tags=["community", "otx"],
#                     raw={"line": line}
#                 )
#             )

#         status["count"] = len(iocs)

#     except Exception as e:
#         LOG.error(f"OTX failure: {e}")
#         status.update({"status": "error", "error": str(e)})

#     return iocs, status

def fetch_otx_iocs(limit: int = 10):
    status = {"source": "AlienVault OTX", "status": "active", "count": 0}
    iocs = []

    try:
        headers = {"X-OTX-API-KEY": OTX_API_KEY}
        r = requests.get(
            "https://otx.alienvault.com/api/v1/pulses/activity",
            headers=headers,
            params={"limit": limit},
            timeout=30
        )
        r.raise_for_status()

        pulses = r.json().get("results", [])

        for pulse in pulses:
            tags = pulse.get("tags", [])
            malware = pulse.get("malware_families", [])

            for indicator in pulse.get("indicators", []):
                iocs.append(
                    normalize_ioc(
                        source="AlienVault OTX",
                        ioc_type=indicator.get("type"),
                        value=indicator.get("indicator"),
                        confidence=90,
                        tags=tags + malware,
                        raw={
                            "pulse": pulse.get("name"),
                            "description": pulse.get("description")
                        }
                    )
                )

        status["count"] = len(iocs)

    except Exception as e:
        status.update({"status": "error", "error": str(e)})

    return iocs, status

# ============================================================
# NVD FEED
# ============================================================

def fetch_nvd_cves(limit: int = 50) -> Tuple[List[Dict], Dict]:
    status = {"source": "NVD", "status": "active", "count": 0}
    iocs = []

    try:
        r = requests.get(
            NVD_CVE_URL,
            params={"resultsPerPage": limit},
            timeout=REQUEST_TIMEOUT
        )
        r.raise_for_status()

        data = r.json()

        for v in data.get("vulnerabilities", []):
            cve = v["cve"]
            severity = (
                cve.get("metrics", {})
                .get("cvssMetricV31", [{}])[0]
                .get("cvssData", {})
                .get("baseSeverity", "UNKNOWN")
            )

            iocs.append(
                normalize_ioc(
                    source="NVD",
                    ioc_type="CVE",
                    value=cve["id"],
                    confidence=95,
                    tags=["vulnerability", severity],
                    raw={"description": cve["descriptions"][0]["value"]}
                )
            )

        status["count"] = len(iocs)

    except Exception as e:
        LOG.error(f"NVD failure: {e}")
        status.update({"status": "error", "error": str(e)})

    return iocs, status

# ============================================================
# ABUSEIPDB FEED (401 SAFE)
# ============================================================

def fetch_abuseipdb_iocs(limit: int = 1000) -> Tuple[List[Dict], Dict]:
    status = {"source": "AbuseIPDB", "status": "active", "count": 0}
    iocs = []

    headers = {
        "Key": ABUSEIPDB_API_KEY,
        "Accept": "application/json"
    }

    params = {"confidenceMinimum": 75, "limit": limit}

    try:
        r = requests.get(
            ABUSEIPDB_URL,
            headers=headers,
            params=params,
            timeout=REQUEST_TIMEOUT
        )

        # === Explicit 401 Handling ===
        if r.status_code == 401:
            LOG.warning("AbuseIPDB unauthorized (401). Check API key.")
            status.update({
                "status": "warning",
                "error": "Unauthorized (401) – invalid or revoked API key"
            })
            return [], status

        r.raise_for_status()

        for item in r.json().get("data", []):
            iocs.append(
                normalize_ioc(
                    source="AbuseIPDB",
                    ioc_type="IP",
                    value=item["ipAddress"],
                    confidence=item["abuseConfidenceScore"],
                    tags=["abuse", "ip"],
                    raw=item
                )
            )

        status["count"] = len(iocs)

    except requests.exceptions.Timeout:
        status.update({"status": "error", "error": "Request timeout"})

    except requests.exceptions.RequestException as e:
        status.update({"status": "error", "error": str(e)})

    return iocs, status

# ============================================================
# AGGREGATOR
# ============================================================

def collect_all_feeds() -> Dict[str, Any]:
    all_iocs = []
    feed_status = []

    for fetcher in (fetch_otx_iocs, fetch_nvd_cves, fetch_abuseipdb_iocs):
        iocs, status = fetcher()
        all_iocs.extend(iocs)
        feed_status.append(status)

    return {
        "ioc_count": len(all_iocs),
        "feeds": feed_status,
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "iocs": all_iocs
    }

# ============================================================
# ENTRYPOINT
# ============================================================

if __name__ == "__main__":
    result = collect_all_feeds()

    LOG.info(f"Total IOCs collected: {result['ioc_count']}")
    for feed in result["feeds"]:
        LOG.info(feed)
